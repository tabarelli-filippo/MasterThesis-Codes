clear; close all; clc;

addpath('functions/');
%% inizializzazione
[data, theta_target] = initialize_rotor_model('rigid'); 
N = data.N;

%% scalatura
K_blade_block = data.K_nom(data.idx_blades, data.idx_blades);
k_ref = mean(diag(K_blade_block));

scale.d0 = 0.01 * k_ref;      
scale.ar = 0.01 * k_ref;         
scale.ai = 0.001 * k_ref;          
data.J_normalization = 1 / sum(sum(abs(data.y).^2));
scale.f  = 1.0;      
data.scale = scale;

%% guess primo tentativo
perturbation_magnitude = 0.05; 
d0_exact_norm = theta_target(1:N) / scale.d0;

% Initial Guess Completa
theta0_d0 = d0_exact_norm + (randn(N, 1) * perturbation_magnitude);
theta0_ar = 1e-4 * ones(N, 1);
theta0_ai = 1e-6 * ones(N, 1); 

% Forcing Guess (EO=6)
Target_EO = 6; 
phase_vec = (0:N-1)' * (2*pi * Target_EO / N);
theta0_fr = 1.0 * cos(phase_vec);
theta0_fi = 1.0 * sin(phase_vec);

theta0_full = [theta0_d0; theta0_ar; theta0_ai; theta0_fr; theta0_fi];

% Bounds Completi
lb_d0 = -20 * ones(N, 1);    ub_d0 =  20 * ones(N, 1);
lb_ar = -10 * ones(N, 1);    ub_ar =  10 * ones(N, 1);
lb_ai = -1 * ones(N, 1);    ub_ai =  1 * ones(N, 1);
lb_fr = -20 * ones(N, 1);    ub_fr =  20 * ones(N, 1); % Ho allargato i bounds forcing per sicurezza
lb_fi = -10 * ones(N, 1);    ub_fi =  10 * ones(N, 1);

lb_full = [lb_d0; lb_ar; lb_ai; lb_fr; lb_fi]; 
ub_full = [ub_d0; ub_ar; ub_ai; ub_fr; ub_fi]; 

%% Vincolo ar
% [d0 (1:N), ar (N+1:2N), ai, fr, fi]
idx_fixed = 2*N; %
fixed_val = 0;

idx_mask = true(5*N, 1);
idx_mask(idx_fixed) = false;

theta0_opt = theta0_full(idx_mask);
lb_opt     = lb_full(idx_mask);
ub_opt     = ub_full(idx_mask);

wrapper_fun = @(t) rotor_objective_wrapper_fixed(t, idx_mask, idx_fixed, fixed_val, data);

%% solver
options = optimoptions('fmincon', ...
    'Algorithm', 'interior-point', ...
    'SpecifyObjectiveGradient', true, ... 
    'HessianApproximation', 'lbfgs', ...
    'Display', 'iter-detailed', ...
    'MaxIterations', 500000, ...
    'MaxFunctionEvaluations', 1000000, ...
    'StepTolerance', 1e-12, ...
    'OptimalityTolerance', 1e-5);

[theta_opt_reduced, final_J, exitflag] = fmincon(wrapper_fun, ...
                                    theta0_opt, [], [], [], [], lb_opt, ub_opt, [], options);

%% plot
theta_final_full = zeros(5*N, 1);
theta_final_full(idx_mask) = theta_opt_reduced;
theta_final_full(idx_fixed) = fixed_val;

d0_opt = theta_final_full(1:N);
ar_opt = theta_final_full(N+1 : 2*N);
ai_opt = theta_final_full(2*N+1 : 3*N);
fr_opt = theta_final_full(3*N+1 : 4*N);
fi_opt = theta_final_full(4*N+1 : 5*N);

d0_init = theta0_full(1:N);
ar_init = theta0_full(N+1 : 2*N);
ai_init = theta0_full(2*N+1 : 3*N);
fr_init = theta0_full(3*N+1 : 4*N);
fi_init = theta0_full(4*N+1 : 5*N);

d0_tgt = theta_target(1:N) / scale.d0;
ar_tgt = theta_target(N+1 : 2*N) / scale.ar;
ai_tgt = theta_target(2*N+1 : 3*N) / scale.ai;
fr_tgt = theta_target(3*N+1 : 4*N) / scale.f;
fi_tgt = theta_target(4*N+1 : 5*N) / scale.f;

figure('Name', 'Results Tiled', 'WindowStyle', 'docked', 'Color', 'w');
tlo = tiledlayout(2, 2, 'Padding', 'compact', 'TileSpacing', 'compact');

col_bar  = [1 1 0.2];   
col_err  = 'r';         
col_init = [0 0.7 0];   

% 1. Mistuning
nexttile;
h_exact = bar(1:N, d0_tgt, 'FaceColor', col_bar, 'EdgeColor', [0.5 0.5 0.5]); hold on;
h_init  = plot(1:N, d0_init, 'LineStyle', 'none', 'Marker', 'o', 'MarkerSize', 5, ...
    'MarkerFaceColor', col_init, 'Color', col_init);
h_est   = errorbar(1:N, d0_opt, ones(N,1)*sigma_val, 'LineStyle', 'none', 'Marker', 's', ...
    'MarkerSize', 4, 'MarkerFaceColor', col_err, 'Color', col_err);
grid on; title('Mistuning (d_0)'); ylabel('d_0'); xlim([0 N+1]);

% 2. Aero Stiffness
nexttile;
bar(1:N, ar_tgt, 'FaceColor', col_bar, 'EdgeColor', [0.5 0.5 0.5]); hold on;
plot(1:N, ar_init, 'o', 'MarkerSize', 5, 'MarkerFaceColor', col_init, 'Color', col_init);
errorbar(1:N, ar_opt, ones(N,1)*sigma_val, 'LineStyle', 'none', 'Marker', 's', ...
    'MarkerFaceColor', col_err, 'Color', col_err);
h_fixed = plot(N, ar_opt(end), 'bo', 'MarkerSize', 8, 'LineWidth', 2);
grid on; title('Aero Stiffness (Real)'); ylabel('a_R'); xlim([0 N+1]);

% 3. Aero Damping
nexttile;
bar(1:N, ai_tgt, 'FaceColor', col_bar, 'EdgeColor', [0.5 0.5 0.5]); hold on;
plot(1:N, ai_init, 'o', 'MarkerSize', 5, 'MarkerFaceColor', col_init, 'Color', col_init);
errorbar(1:N, ai_opt, ones(N,1)*sigma_val, 'LineStyle', 'none', 'Marker', 's', ...
    'MarkerFaceColor', col_err, 'Color', col_err);
grid on; title('Aero Damping (Imag)'); ylabel('a_I'); xlim([0 N+1]);

% 4. Forcing Spectrum
nexttile;
f_vec_tgt_c = fr_tgt + 1i * fi_tgt;
F_nodal_tgt = fftshift(fft(f_vec_tgt_c)/N);
f_vec_opt_c = fr_opt + 1i * fi_opt;
F_nodal_opt = fftshift(fft(f_vec_opt_c)/N);
f_vec_init_c = fr_init + 1i * fi_init;
F_nodal_init = fftshift(fft(f_vec_init_c)/N);

if mod(N, 2) == 0, nd_axis = (-N/2 : N/2-1); else, nd_axis = (-(N-1)/2 : (N-1)/2); end
bar(nd_axis, abs(F_nodal_tgt), 'FaceColor', col_bar, 'EdgeColor', [0.5 0.5 0.5]); hold on;
plot(nd_axis, abs(F_nodal_init), 'o', 'MarkerSize', 5, 'MarkerFaceColor', col_init, 'Color', col_init);
errorbar(nd_axis, abs(F_nodal_opt), ones(N,1)*(sigma_val*0.5), 'LineStyle', 'none', 'Marker', 's', ...
    'MarkerFaceColor', col_err, 'Color', col_err);
grid on; title('Forcing Spectrum'); xlabel('ND'); xlim([-16 16]);


lgd = legend([h_exact, h_init, h_est, h_fixed], ...
    {'Exact Model', 'Initial Guess', 'ML Estimate', 'Fixed (Zero)'});
lgd.Layout.Tile = 'east'; 

title(tlo, 'Identificazione Parametri Rotore: Analisi Residui', 'FontSize', 14, 'FontWeight', 'bold');
%% Helper function 
function [J, grad_reduced] = rotor_objective_wrapper_fixed(theta_reduced, idx_mask, idx_fixed, fixed_val, data)
    theta_full = zeros(length(idx_mask), 1);
    theta_full(idx_mask) = theta_reduced;
    theta_full(idx_fixed) = fixed_val;
    
    [J, grad_full] = rotor_objective_with_grad(theta_full, data);
    
    grad_reduced = grad_full(idx_mask);
end
