function [data, theta_true] = initialize_rotor_model(model_type)
%INITIALIZE_ROTOR_MODEL Genera dati per grafico "Single Engine Order"

    if nargin < 1, model_type = 'rigid'; end
    fprintf('Inizializzazione Modello: %s (Setup per Plot Nodal Diameter)\n', upper(model_type));

    %% 1. Parametri Fisici del Rotore (Purdue Rotor 2)
    data.N = 33;          % Numero di pale
    f0_Hz  = 2760;        % Frequenza naturale nominale 1T (Hz)
    w0     = 2*pi*f0_Hz;  % Pulsazione rad/s
    
    engine_order = 6; 
    
    rpm_center =  f0_Hz * 60 / engine_order; 
    rpm_span   = 400; 
    N_steps    = 1000;  
    
    rpm_vec = linspace(rpm_center - rpm_span, rpm_center + rpm_span, N_steps);
    data.omega = rpm_vec /30*pi* engine_order; 
    
    %% 2. Generazione Matrici ROM (Seed Bloccato)
    rng(42); % Struttura fissa
    
    switch lower(model_type)
        case 'rigid'
            data.M_mat = eye(data.N);
            data.K_nom = (w0^2) * eye(data.N);
            data.idx_blades = 1:data.N;
            
        case 'flexible'
            M_bb = eye(data.N);
            K_bb = (w0^2) * eye(data.N);
            N_disk = data.N;
            M_dd = eye(N_disk);
            nd = linspace(-1, 1, N_disk); 
            freqs_disk = w0 * (0.8 + 0.4 * abs(nd).^2); 
            
            zeta_disk = 1e-4;
            K_dd_real = diag(freqs_disk.^2);
            K_dd = K_dd_real * (1 + 1i * 2* zeta_disk);
            coup_factor = 0.05; 
            M_bd = coup_factor * (rand(data.N, N_disk) - 0.5); 
            K_bd = coup_factor * w0^2 * (rand(data.N, N_disk) - 0.5);

            data.M_mat = [M_dd, M_bd'; M_bd, M_bb];
            data.K_nom = [K_dd, K_bd'; K_bd, K_bb];
            data.idx_blades = (N_disk + 1) : (N_disk + data.N);
        otherwise
            error('Tipo modello non supportato.');
    end

    %% 3. Generazione "Ground Truth" (Parametri Veri)
    rng(1); % Parametri fissi
    
    % A. Mistuning Casuale
    sigma_mistuning = 0.03 * w0^2; 
    d0_true = sigma_mistuning * randn(data.N, 1);
    
    % B. Aerodinamica
    a_real_true = zeros(data.N, 1);
    a_imag_true = zeros(data.N, 1);
    k_aero = 0.005 * w0^2; 
    
    a_imag_true(1) = 0.05*k_aero;
    a_imag_true(2) = 0.02*k_aero; a_imag_true(end) = k_aero*0.04; 
    
    a_real_true(2) = 0.004 * w0^2;  
    
    f_scalar_amp = 0.232;          
    f_scalar_phase = deg2rad(0);
    f_scalar_complex = f_scalar_amp * exp(1i * f_scalar_phase);
    
    % E - wave_shape 
    wave_shape = exp(1i * (0:data.N-1)' * (2*pi * engine_order / data.N));
    f_vec_true = f_scalar_complex * wave_shape;
    
    f_real_true = real(f_vec_true);
    f_imag_true = imag(f_vec_true);
    
    theta_true = [d0_true; a_real_true; a_imag_true; f_real_true; f_imag_true];

    %% 4. Simulazione Risposta (Forward Run)
    fprintf('Generazione dati per EO=%d (Target Nodal Diameter: %d)...\n', engine_order, engine_order);
    
    A_sys = data.K_nom;
    idx = data.idx_blades;
    D0_mat = diag(d0_true);

    % circulant matrix
    mk_circ = @(v) toeplitz(v(end:-1:1), [v(end); v(1:end-1)]);
    A_aero_mat = mk_circ(a_real_true) + 1i * mk_circ(a_imag_true);
    
    A_sys(idx, idx) = A_sys(idx, idx) + D0_mat + A_aero_mat;
    F_sys = zeros(size(A_sys, 1), 1);
    F_sys(idx) = f_vec_true;
    
    data.y = zeros(data.N, length(data.omega));
    
    for k = 1:length(data.omega)
        wk = data.omega(k);
        Z = A_sys - (wk^2) * data.M_mat;
        x_full = Z \ F_sys;
        data.y(:, k) = x_full(idx);
    end
    
    %% 5. Aggiunta Rumore
    noise_level = 0;
    data.sigmaNoise = noise_level * max(abs(data.y(:)));
    noise = noise_level * max(abs(data.y(:))) * (randn(size(data.y)) + 1i*randn(size(data.y)));
    data.y = data.y + noise;
    
    fprintf('Setup Completato. RPM Center: %.0f\n', rpm_center);
end