function [Mb,Cb,Kb,zero_dof, eccentricity] = bearingMatrix(Rotor,rotorSpeed)
%BEARINGMATRIX  calculates the mass, stiffness and damping matrices for the
% bearings. Also gives the list of constrained dofs
%
% INPUT:Rotor       Structure
%       rotorSpeed  Double ONLY
%
%
% OUTPUT:   Mb  Bearing Mass matrix
%           Cb  Bearing Damping matrix
%           Kb  Bearing Stiffness matrix
%           zero_dof  Constrained Dofs

nodes = Rotor.nodes;
bearings = Rotor.bearing;

% initialize matrices
n_nodes  = numel(nodes);
nBearing = numel(bearings);
ndof = 4 * n_nodes;


Mb = zeros(ndof,ndof);
Cb = zeros(ndof,ndof);
Kb = zeros(ndof,ndof);
zero_dof = [];

eccentricity = zeros(nBearing,1);

for ii = 1:nBearing
    type = bearings(ii).type;

    Kb1 = zeros(4,4);
    Cb1 = zeros(4,4);
    Mb1 = zeros(4,4);
    switch type
        case 1 % pinned bearing
            n1 = bearings(ii).node;
            zero_dof = [zero_dof 4*n1-3 4*n1-2];

        case 2 % long, stiff bearing - clamped boundary condition
            n1 = bearings(ii).node;
            zero_dof = [zero_dof 4*n1-3:4*n1];

        case 3       % constant stiffness and damping, diagonal, no rotations
            
            kx=0; ky=0; cx=0; cy=0;

            if isfield(Rotor.bearing(ii), 'kx'), kx = Rotor.bearing(ii).kx; end
            if isfield(Rotor.bearing(ii), 'ky'), ky = Rotor.bearing(ii).ky; end
            if isfield(Rotor.bearing(ii), 'cx'), cx = Rotor.bearing(ii).cx; end
            if isfield(Rotor.bearing(ii), 'cy'), cy = Rotor.bearing(ii).cy; end

            Kb1 = diag( [kx ky 0 0] );
            Cb1 = diag( [cx cy 0 0] );

        case 4       % constant stiffness and damping, diagonal
            if isfield(Rotor.bearing(ii), 'k')
                k = Rotor.bearing(ii).k;
            else
                k = zeros(4,1);
            end

            if isfield(Rotor.bearing(ii), 'c')
                c = Rotor.bearing(ii).c;
            else
                c = zeros(4,1);
            end

            Kb1 = diag(k);
            Cb1 = diag(c);

        case 5       % constant stiffness and damping, no rotations
            if isfield(Rotor.bearing(ii), 'K')
                K = Rotor.bearing(ii).K;
            else
                K = zeros(2,2);
            end

            if isfield(Rotor.bearing(ii), 'C')
                C = Rotor.bearing(ii).C;
            else 
                C = zeros(2,2);
            end

            Z = zeros(2,2);
            Kb1 = [ K, Z ; Z , Z ];
            Cb1 = [ C, Z ; Z , Z ];

        case 6      % constant stiffness and damping, full 4x4 matrices required
            if isfield(Rotor.bearing(ii), 'K')
                K = Rotor.bearing(ii).K;
            else
                K = zeros(4,4);
            end
            if isfield(Rotor.bearing(ii), 'C')
                C = Rotor.bearing(ii).C;
            else
                C = zeros(4,4);
            end

            Kb1 = K;
            Cb1 = C;

        case 7      % fluid film bearings - Linear behaviour
            if isfield(Rotor.bearing(ii), 'F'), F = Rotor.bearing(ii).F; end % static load [N]
            if isfield(Rotor.bearing(ii), 'D'), D = Rotor.bearing(ii).D; end % bearing diameter [m]
            if isfield(Rotor.bearing(ii), 'L'), L = Rotor.bearing(ii).L; end % bearing length [m]
            if isfield(Rotor.bearing(ii), 'c'), c = Rotor.bearing(ii).c; end % bearing radial clearance [m]
            if isfield(Rotor.bearing(ii), 'eta'), eta = Rotor.bearing(ii).eta; end % oil viscosity [Ns/m^2]
            
            Linear = 0;
            if isfield(Rotor.bearing(ii), 'Linear'), Linear = Rotor.bearing(ii).Linear; end % 1 if not linear

            if rotorSpeed == 0
                error('>>>> Error - bearing type 7 - fluid bearing model undefined at zero speed')
            end

            % Find roots of quartic in n^2  (n is eccentricity ratio)
            H = ( 8*c^2*F/(D*rotorSpeed*eta*L^3) )^2;
            n2all = sort( roots([1 -4 (6-(16-pi^2)/H) -(4+pi^2/H) 1]) );
            nroot = 0; n2 = []; % test roots - eccentricity should be between 0 and 1

            % check if solution exists
            for ir=1:4
                nn = n2all(ir);
                if nn>0 && nn<1 && isreal(nn)
                    nroot = nroot + 1;
                    n2 = [n2; nn];
                end
            end

            if nroot == 0
                n2 = 0.5;
                disp('Error in calculating fluid bearing coefficents - no solutions for eccentricity')
            end
            if nroot >= 2
                n2 = min(n2);
                disp('Error in calculating fluid bearing coefficents - multiple solutions for eccentricity')
            end

            % Compute damping and stiffness matrices
            a = zeros(2,2); b = zeros(2,2);
            n = sqrt(n2);
            eccentricity(ii) = n;
            q1 = (1-n2); q2 = (1+n2); q3 = (1+2*n2); p2 = pi^2;
            de = (p2*q1+16*n2)^1.5;
            a(1,1) = 4*(p2*(2-n2)+16*n2)/de;
            a(2,2) = 4*(p2*q1*q3+32*n2*q2)/(q1*de);
            a(1,2) = pi*(p2*q1^2-16*n^4)/(n*sqrt(q1)*de);
            a(2,1) = -pi*(p2*q1*q3+32*n2*q2)/(n*sqrt(q1)*de);
            b(1,1) = 2*pi*sqrt(q1)*(p2*q3-16*n2)/(n*de);
            b(2,2) = 2*pi*(p2*q1^2+48*n2)/(n*sqrt(q1)*de);
            b(1,2) = -8*(p2*q3-16*n2)/de;
            b(2,1) = b(1,2);
            
            Kb1 = zeros(4,4); Cb1 = zeros(4,4);

            if Linear == 0
                Kb1(1:2,1:2) = (F/c)*a;
                Cb1(1:2,1:2) = (F/(c*rotorSpeed))*b;
            end

        case 8 %Seal 
            if isfield(Rotor.bearing(ii), 'P'), P = Rotor.bearing(ii).P; end  % pressure difference across seal %[Pa]
            if isfield(Rotor.bearing(ii), 'R'), R = Rotor.bearing(ii).R; end % seal radius [m]
            if isfield(Rotor.bearing(ii), 'L'), L = Rotor.bearing(ii).L; end % seal length [m]
            if isfield(Rotor.bearing(ii), 'c'), c = Rotor.bearing(ii).c; end % seal radial clearance [m]
            if isfield(Rotor.bearing(ii), 'V'), V = Rotor.bearing(ii).V; end % seal average axial stream velocity [m/s]
            if isfield(Rotor.bearing(ii), 'fric'), fric = Rotor.bearing(ii).fric; end % friction coefficient
            
            T = L/V;
            sigma = fric*L/c;
            epsilon = pi*sigma*R*P/(6*fric*(1.5+2*sigma));
            mu_0 = 9*sigma/(1.5+2*sigma);
            mu_1 = ( (3+2*sigma)^2*(1.5+2*sigma) - 9*sigma ) / (1.5+2*sigma)^2;
            mu_2 = ( 19*sigma + 18*sigma^2 + 8*sigma^3 ) / (1.5+2*sigma)^3;

            Kb1(1:2,1:2) = epsilon*(mu_0-mu_2*T^2*rotorSpeed^2/4)*eye(2,2) + epsilon*(mu_1*T*rotorSpeed/2)*[0 -1; 1 0];
            Cb1(1:2,1:2) = epsilon*mu_1*T*eye(2,2) + epsilon*(mu_2*T^2*rotorSpeed)*[0 -1; 1 0];
            Mb1(1:2,1:2) = epsilon*mu_2*T^2*eye(2,2);
        case 9      % Ball bearing - simplified model 2DOF
            if isfield(Rotor.bearing(ii), 'n_ball'), n_ball = Rotor.bearing(ii).n_ball; end  % number of balls
            if isfield(Rotor.bearing(ii), 'd_ball'), d_ball = Rotor.bearing(ii).d_ball; end % ball diameter [m]
            if isfield(Rotor.bearing(ii), 'fs'), fs = Rotor.bearing(ii).fs; end % Static Load [N]
            if isfield(Rotor.bearing(ii), 'alpha'), alpha = Rotor.bearing(ii).alpha; end % contact angle [rad]
            
            kb = 13e6;  %[(N^2/m^4)^(1/3)]

            if ~(n_ball == 8 || n_ball == 12 || n_ball == 16)
                error('Bearing Type 9 - Number of balls not valid')
            end
            
            switch n_ball
                case 8
                    coeff = 0.46;
                case 12
                    coeff = 0.64;
                case 16
                    coeff = 0.73;
            end

            kvv = kb * (n_ball^2 * d_ball * fs * cos(alpha)^5)^(1/3);
            kuu = coeff * kvv;
            
            Kb1 = zeros(4,4); Kb1(1,1) = kuu; Kb1(2,2) = kvv;

    end

    nnode = bearings(ii).node;
    dof = (4*nnode-3):4*nnode;
    Kb(dof,dof) = Kb(dof,dof) + Kb1;
    Cb(dof,dof) = Cb(dof,dof) + Cb1;
    Mb(dof,dof) = Mb(dof,dof) + Mb1;
end
end