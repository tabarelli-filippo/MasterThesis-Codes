function [eigenvalues,eigenvectors,kappa] = charRoots(Rotor,rotorSpeed)
%CHARROOTS: computes Natural frequencies [rad/s] and  Modes of a rotor for
% a given constant rotor Speed.
%
%INPUT: Rotor: Structure (Reference on Manual)
%       rotorSpeed: Double or Vector - rotational speed
%
%OUTPUT: natPuls: Vector of the natural frequencies [rad/s]
%       Mode: Matrix or nxnx3 Tensor of modes

arguments (Input)
    Rotor (1,1) struct
    rotorSpeed (:,:) double {mustBeVector}
end

if nargout > 1
    % initialize solutions
    n_nodes = numel(Rotor.nodes);
    nspeed = length(rotorSpeed);
    
    ndof = 4 * n_nodes;

    % define global matrices
    [M0,C0,C1,K0,K1] = rotorMatrix(Rotor);
    [Mb,Cb,Kb,zero_dof,~] = bearingMatrix(Rotor,rotorSpeed(1));

    % sort out zeroed DoF
    dof = 1:ndof;
    dof(zero_dof) = [];
    nzero = length(zero_dof);
    ncdof = ndof - nzero;

    eigenvalues = zeros(ncdof,nspeed);
    
    if nspeed==1
        eigenvectors = zeros(ndof,ncdof);
    else
        eigenvectors = zeros(ndof,ncdof,nspeed);
    end

    % finding eigevalues for each speed
    for ii = 1:nspeed
        [Mb,Cb,Kb,~,~] = bearingMatrix(Rotor,rotorSpeed(ii));

        % speed-dependent global matrices
        M = M0 + Mb;
        K = K0 + Kb + rotorSpeed(ii)*K1;
        C = C0 + Cb + rotorSpeed(ii)*C1;

        % eigenvalues and eigevector
        AA = [zeros(ncdof,ncdof) eye(ncdof,ncdof); -M(dof,dof)\K(dof,dof) -M(dof,dof)\C(dof,dof)];
        [eigenvectors_Spd,eigenvalues_Spd] = eig(AA);
        [eigenvalues_Spd,isort] = sort(diag(eigenvalues_Spd));
        eigenvectors_Spd = eigenvectors_Spd(:,isort);
        eigenvalues(:,ii) = eigenvalues_Spd(1:2:2*ncdof);

        if nspeed == 1
            eigenvectors(dof,:) = eigenvectors_Spd(1:ncdof,1:ncdof); % ndof x ncdof
        else
            eigenvectors(dof,:,ii) = eigenvectors_Spd(1:ncdof,1:ncdof); % ndof x ncdof x nspeed
        end
    end
end

if nargout > 2
    if nspeed==1
        kappa = zeros(ndof,ncdof);
    else
        kappa = zeros(ndof,ncdof,nspeed);
    end
    for i = 1:nspeed        % for each speed
        for id = 1:ncdof  % for each eigenvector
            if nspeed == 1
                evector = eigenvectors(:,id);
            else
                evector = eigenvectors(:,id,i);
            end
            kk = modeWhirl(evector(1:2:ndof),evector(2:2:ndof));
            if imag(eigenvalues(id,i)) < 0
                kk = -kk;
            end
            if nspeed == 1
                kappa(1:2:ndof,id) = kk;
                kappa(2:2:ndof,id) = kk;
            else
                kappa(1:2:ndof,id,i) = kk;
                kappa(2:2:ndof,id,i) = kk;
            end
        end
    end
end
end
